import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';

const db = new Database('finance.db');

console.log('Initializing database schema...');

db.exec(`
  CREATE TABLE IF NOT EXISTS fixed_expenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    amount REAL NOT NULL,
    due_day INTEGER NOT NULL,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS fixed_expense_payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fixed_expense_id INTEGER NOT NULL,
    month INTEGER NOT NULL,
    year INTEGER NOT NULL,
    status TEXT DEFAULT 'Pending',
    paid_at DATETIME,
    FOREIGN KEY (fixed_expense_id) REFERENCES fixed_expenses(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL,
    description TEXT NOT NULL,
    category TEXT NOT NULL,
    amount REAL NOT NULL,
    type TEXT NOT NULL, -- 'Receita' or 'Despesa'
    payment_method TEXT,
    notes TEXT,
    receipt_path TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS patients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    dob TEXT,
    cpf_id TEXT,
    phone TEXT,
    address TEXT,
    city TEXT,
    state TEXT,
    responsible_person TEXT,
    responsible_contact TEXT,
    entry_date TEXT,
    exit_date TEXT,
    medical_observations TEXT,
    status TEXT DEFAULT 'Ativo', -- 'Ativo' or 'Alta'
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS patient_documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    file_path TEXT NOT NULL,
    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS vaquinhas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    goal_amount REAL,
    current_amount REAL DEFAULT 0,
    pix_key TEXT,
    status TEXT DEFAULT 'Aberta', -- 'Aberta' or 'Encerrada'
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS bill_reminders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    month TEXT NOT NULL, -- Format: 'MM/YYYY'
    amount REAL DEFAULT 0,
    due_date TEXT,
    notes TEXT,
    status TEXT DEFAULT 'Pendente', -- 'Pendente' or 'Enviado'
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    name TEXT NOT NULL,
    role TEXT DEFAULT 'User', -- 'Admin' or 'User'
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

console.log('Seeding database...');

try {
  // Clear existing data (optional, but good for a clean seed)
  // db.exec('DELETE FROM fixed_expense_payments');
  // db.exec('DELETE FROM fixed_expenses');
  // db.exec('DELETE FROM transactions');
  // db.exec('DELETE FROM patients');
  // db.exec('DELETE FROM vaquinhas');
  // db.exec('DELETE FROM bill_reminders');

  // 1. Fixed Expenses
  const insertFixedExpense = db.prepare('INSERT INTO fixed_expenses (name, description, amount, due_day, notes) VALUES (?, ?, ?, ?, ?)');
  const rent = insertFixedExpense.run('Aluguel', 'Aluguel do imóvel', 2500.00, 10, 'Pagamento via transferência').lastInsertRowid;
  const energy = insertFixedExpense.run('Energia Elétrica', 'Conta de luz - CPFL', 350.00, 15, '').lastInsertRowid;
  const water = insertFixedExpense.run('Água', 'Conta de água - Sabesp', 120.00, 20, '').lastInsertRowid;
  const internet = insertFixedExpense.run('Internet', 'Fibra Óptica 500MB', 150.00, 5, '').lastInsertRowid;

  // 2. Fixed Expense Payments (Last 6 months)
  const insertPayment = db.prepare('INSERT INTO fixed_expense_payments (fixed_expense_id, month, year, status, paid_at) VALUES (?, ?, ?, ?, ?)');
  const now = new Date();
  for (let i = 0; i < 6; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const m = d.getMonth() + 1;
    const y = d.getFullYear();
    
    insertPayment.run(rent, m, y, 'Paid', d.toISOString());
    insertPayment.run(energy, m, y, 'Paid', d.toISOString());
    insertPayment.run(water, m, y, 'Paid', d.toISOString());
    insertPayment.run(internet, m, y, 'Paid', d.toISOString());
  }

  // 3. Transactions
  const insertTransaction = db.prepare('INSERT INTO transactions (date, description, category, amount, type, payment_method, notes) VALUES (?, ?, ?, ?, ?, ?, ?)');
  
  // Income
  insertTransaction.run('2026-03-01', 'Mensalidade Paciente A', 'Mensalidade', 3000.00, 'Receita', 'PIX', '');
  insertTransaction.run('2026-03-05', 'Mensalidade Paciente B', 'Mensalidade', 3000.00, 'Receita', 'Transferência', '');
  insertTransaction.run('2026-02-01', 'Mensalidade Paciente A', 'Mensalidade', 3000.00, 'Receita', 'PIX', '');
  
  // Expenses
  insertTransaction.run('2026-03-02', 'Supermercado Mensal', 'Alimentação', 1200.00, 'Despesa', 'Cartão de Crédito', 'Compras para o mês');
  insertTransaction.run('2026-03-10', 'Farmácia', 'Saúde', 250.00, 'Despesa', 'Dinheiro', 'Medicamentos diversos');
  insertTransaction.run('2026-02-15', 'Manutenção Ar Condicionado', 'Manutenção', 400.00, 'Despesa', 'PIX', '');

  // 4. Patients
  const insertPatient = db.prepare(`
    INSERT INTO patients (full_name, dob, cpf_id, phone, address, city, state, responsible_person, responsible_contact, entry_date, status, medical_observations)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  insertPatient.run('João da Silva', '1945-05-15', '123.456.789-00', '(11) 98888-7777', 'Rua das Flores, 123', 'São Paulo', 'SP', 'Maria da Silva', '(11) 97777-6666', '2025-10-01', 'Ativo', 'Hipertenso, necessita de acompanhamento diário.');
  insertPatient.run('Maria Oliveira', '1950-08-20', '987.654.321-11', '(11) 96666-5555', 'Av. Paulista, 1000', 'São Paulo', 'SP', 'Carlos Oliveira', '(11) 95555-4444', '2026-01-15', 'Ativo', 'Diabetes tipo 2, dieta controlada.');
  insertPatient.run('Antônio Santos', '1938-12-10', '456.789.123-22', '(11) 94444-3333', 'Rua Augusta, 500', 'São Paulo', 'SP', 'Ana Santos', '(11) 93333-2222', '2024-05-20', 'Ativo', 'Alzheimer em estágio inicial.');

  // 5. Vaquinhas
  const insertVaquinha = db.prepare('INSERT INTO vaquinhas (title, description, goal_amount, current_amount, pix_key, status) VALUES (?, ?, ?, ?, ?, ?)');
  insertVaquinha.run('Reforma da Cozinha', 'Precisamos reformar a cozinha para melhor atender nossos pacientes.', 15000.00, 4500.00, 'financeiro@fintrack.com', 'Aberta');
  insertVaquinha.run('Cadeiras de Rodas Novas', 'Campanha para compra de 5 novas cadeiras de rodas motorizadas.', 25000.00, 12000.00, '11988887777', 'Aberta');

  // 6. Bill Reminders
  const insertReminder = db.prepare('INSERT INTO bill_reminders (name, month, amount, due_date, notes, status) VALUES (?, ?, ?, ?, ?, ?)');
  const monthYear = `${(now.getMonth() + 1).toString().padStart(2, '0')}/${now.getFullYear()}`;
  insertReminder.run('IPTU 2026', monthYear, 450.00, '2026-03-15', 'Parcela 3/10', 'Pendente');
  insertReminder.run('Seguro Predial', monthYear, 800.00, '2026-03-25', 'Renovação anual', 'Pendente');

  // 7. Users
  const insertUser = db.prepare('INSERT INTO users (username, password, name, role) VALUES (?, ?, ?, ?)');
  const adminPassword = bcrypt.hashSync('admin123', 10);
  insertUser.run('admin', adminPassword, 'Administrador', 'Admin');
  const userPassword = bcrypt.hashSync('user123', 10);
  insertUser.run('user', userPassword, 'Usuário Padrão', 'User');

  console.log('Database seeded successfully!');
} catch (error) {
  console.error('Error seeding database:', error);
} finally {
  db.close();
}
