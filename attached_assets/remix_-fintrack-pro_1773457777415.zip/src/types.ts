export interface FixedExpense {
  id: number;
  name: string;
  description: string;
  amount: number;
  due_day: number;
  notes: string;
  status: 'Pago' | 'Pendente';
  paid_at: string | null;
}

export interface Transaction {
  id: number;
  date: string;
  description: string;
  category: string;
  amount: number;
  type: 'Receita' | 'Despesa';
  payment_method: string;
  notes: string;
  receipt_path: string | null;
}

export interface DashboardStats {
  monthlyIncome: number;
  monthlyExpenses: number;
  fixedExpensesTotal: number;
  fixedExpensesPaid: number;
  remainingBalance: number;
}

export interface CategoryReport {
  category: string;
  total: number;
}

export interface FixedExpenseHistory {
  name: string;
  total: number;
  month: number;
  year: number;
}

export interface Patient {
  id: number;
  full_name: string;
  dob: string;
  cpf_id: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  responsible_person: string;
  responsible_contact: string;
  entry_date: string;
  exit_date: string;
  medical_observations: string;
  status: 'Ativo' | 'Alta';
  documents?: PatientDocument[];
}

export interface PatientDocument {
  id: number;
  patient_id: number;
  name: string;
  file_path: string;
  uploaded_at: string;
}

export interface Vaquinha {
  id: number;
  title: string;
  description: string;
  goal_amount: number;
  current_amount: number;
  pix_key: string;
  status: 'Aberta' | 'Encerrada';
  created_at: string;
}

export interface BillReminder {
  id: number;
  name: string;
  month: string;
  amount: number;
  due_date: string;
  notes: string;
  status: 'Pendente' | 'Enviado';
  created_at: string;
}

export interface User {
  id: number;
  username: string;
  name: string;
  role: 'Admin' | 'User';
  created_at: string;
}
