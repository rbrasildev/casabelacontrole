import React, { useState, useEffect, Component, ReactNode } from 'react';
import { 
  LayoutDashboard, 
  Receipt, 
  CalendarClock, 
  BarChart3, 
  Plus, 
  CheckCircle2, 
  AlertCircle,
  TrendingUp,
  TrendingDown,
  Wallet,
  ArrowUpRight,
  ArrowDownRight,
  FileText,
  X,
  Upload,
  Eye,
  Trash2,
  ChevronLeft,
  ChevronRight,
  Users,
  Heart,
  Settings as SettingsIcon,
  MessageCircle,
  Download,
  Bell,
  Send,
  Clock,
  Pencil
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format, startOfMonth, endOfMonth, isAfter, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';
import { cn, formatCurrency } from './utils';
import { FixedExpense, Transaction, DashboardStats, CategoryReport, FixedExpenseHistory, Patient, Vaquinha, BillReminder, User } from './types';

// --- Components ---

const Login = ({ onLogin }: { onLogin: (user: User) => void }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await window.fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      if (!res.ok) throw new Error('Credenciais inválidas');
      const user = await res.json();
      onLogin(user);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-black/5 p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-white p-8 rounded-3xl shadow-xl border border-black/5"
      >
        <div className="flex flex-col items-center mb-8">
          <div className="w-16 h-16 bg-black rounded-2xl flex items-center justify-center mb-4">
            <LayoutDashboard className="text-white" size={32} />
          </div>
          <h1 className="text-2xl font-bold">FinTrack</h1>
          <p className="text-black/50 text-sm">Controle Financeiro & Gestão</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Input 
            label="Usuário" 
            value={username} 
            onChange={(e: any) => setUsername(e.target.value)} 
            required 
          />
          <Input 
            label="Senha" 
            type="password" 
            value={password} 
            onChange={(e: any) => setPassword(e.target.value)} 
            required 
          />
          
          {error && (
            <div className="p-3 bg-red-50 text-red-600 rounded-xl text-sm flex items-center gap-2">
              <AlertCircle size={16} />
              {error}
            </div>
          )}

          <Button type="submit" className="w-full py-3" disabled={loading}>
            {loading ? 'Entrando...' : 'Entrar'}
          </Button>
        </form>
      </motion.div>
    </div>
  );
};

const UserManagement = ({ safeFetch }: any) => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const data = await safeFetch('/api/users');
      setUsers(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleDelete = async (id: number) => {
    if (confirm('Tem certeza que deseja excluir este usuário?')) {
      try {
        await safeFetch(`/api/users/${id}`, { method: 'DELETE' });
        fetchUsers();
      } catch (err: any) {
        alert(err.message);
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Controle de Usuários</h2>
          <p className="text-black/50">Gerencie quem tem acesso ao sistema</p>
        </div>
        <Button onClick={() => setShowAdd(true)}>
          <Plus size={20} /> Novo Usuário
        </Button>
      </div>

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-bottom border-black/5">
                <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-black/50">Nome</th>
                <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-black/50">Usuário</th>
                <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-black/50">Nível</th>
                <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-black/50">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-black/5">
              {users.map(u => (
                <tr key={u.id} className="hover:bg-black/5 transition-colors">
                  <td className="px-6 py-4 font-medium">{u.name}</td>
                  <td className="px-6 py-4 text-black/60">{u.username}</td>
                  <td className="px-6 py-4">
                    <span className={cn(
                      "px-2 py-1 rounded-lg text-xs font-bold uppercase",
                      u.role === 'Admin' ? "bg-purple-100 text-purple-700" : "bg-blue-100 text-blue-700"
                    )}>
                      {u.role}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      <Button variant="ghost" className="p-2" onClick={() => setEditingUser(u)}>
                        <Pencil size={16} />
                      </Button>
                      <Button variant="ghost" className="p-2 text-red-500 hover:text-red-600" onClick={() => handleDelete(u.id)}>
                        <Trash2 size={16} />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <AnimatePresence>
        {(showAdd || editingUser) && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl w-full max-w-md p-8 shadow-2xl"
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold">{editingUser ? 'Editar Usuário' : 'Novo Usuário'}</h3>
                <button onClick={() => { setShowAdd(false); setEditingUser(null); }}><X /></button>
              </div>
              <form onSubmit={async (e: any) => {
                e.preventDefault();
                const formData = new FormData(e.target);
                const data = Object.fromEntries(formData);
                try {
                  if (editingUser) {
                    await safeFetch(`/api/users/${editingUser.id}`, {
                      method: 'PUT',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify(data)
                    });
                  } else {
                    await safeFetch('/api/users', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify(data)
                    });
                  }
                  setShowAdd(false);
                  setEditingUser(null);
                  fetchUsers();
                } catch (err: any) {
                  alert(err.message);
                }
              }} className="space-y-4">
                <Input label="Nome Completo" name="name" defaultValue={editingUser?.name} required />
                <Input label="Nome de Usuário" name="username" defaultValue={editingUser?.username} required />
                <Input label="Senha" name="password" type="password" placeholder={editingUser ? "Deixe em branco para manter" : ""} required={!editingUser} />
                <Select 
                  label="Nível de Acesso" 
                  name="role" 
                  defaultValue={editingUser?.role || 'User'}
                  options={[
                    { value: 'User', label: 'Usuário Padrão' },
                    { value: 'Admin', label: 'Administrador' }
                  ]} 
                />
                <Button type="submit" className="w-full py-3">
                  {editingUser ? 'Salvar Alterações' : 'Criar Usuário'}
                </Button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

// --- Components ---

const Card = ({ children, className, id }: { children: React.ReactNode, className?: string, id?: string, key?: any }) => (
  <div id={id} className={cn("bg-white rounded-2xl border border-black/5 shadow-sm overflow-hidden", className)}>
    {children}
  </div>
);

const Button = ({ children, onClick, variant = 'primary', className, type = 'button', disabled }: any) => {
  const variants = {
    primary: "bg-black text-white hover:bg-black/90",
    secondary: "bg-white text-black border border-black/10 hover:bg-black/5",
    danger: "bg-red-500 text-white hover:bg-red-600",
    ghost: "bg-transparent text-black hover:bg-black/5"
  };
  return (
    <button 
      type={type}
      onClick={onClick} 
      disabled={disabled}
      className={cn("px-4 py-2 rounded-xl font-medium transition-all flex items-center justify-center gap-2 disabled:opacity-50", variants[variant as keyof typeof variants], className)}
    >
      {children}
    </button>
  );
};

const Input = ({ label, ...props }: any) => (
  <div className="space-y-1.5">
    {label && <label className="text-xs font-semibold uppercase tracking-wider text-black/50 ml-1">{label}</label>}
    <input 
      {...props} 
      className="w-full px-4 py-2.5 bg-black/5 border border-transparent rounded-xl focus:bg-white focus:border-black/10 outline-none transition-all"
    />
  </div>
);

const Select = ({ label, options, ...props }: any) => (
  <div className="space-y-1.5">
    {label && <label className="text-xs font-semibold uppercase tracking-wider text-black/50 ml-1">{label}</label>}
    <select 
      {...props} 
      className="w-full px-4 py-2.5 bg-black/5 border border-transparent rounded-xl focus:bg-white focus:border-black/10 outline-none transition-all appearance-none"
    >
      {options.map((opt: any) => (
        <option key={opt.value} value={opt.value}>{opt.label}</option>
      ))}
    </select>
  </div>
);

class ErrorBoundary extends Component<any, any> {
  state = { hasError: false, error: null };

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error("Uncaught error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-red-50 p-4">
          <div className="max-w-md w-full bg-white p-8 rounded-2xl shadow-xl border border-red-100">
            <h1 className="text-2xl font-bold text-red-600 mb-4">Algo deu errado</h1>
            <p className="text-gray-600 mb-6">Ocorreu um erro inesperado na aplicação. Por favor, tente recarregar a página.</p>
            <div className="bg-red-50 p-4 rounded-xl mb-6 overflow-auto max-h-40">
              <code className="text-xs text-red-800">{this.state.error?.toString()}</code>
            </div>
            <button 
              onClick={() => window.location.reload()} 
              className="w-full bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-xl font-medium transition-all"
            >
              Recarregar Página
            </button>
          </div>
        </div>
      );
    }

    return (this as any).props.children;
  }
}

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'patients' | 'vaquinhas' | 'financial' | 'reports' | 'settings' | 'users'>('dashboard');
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [fixedExpenses, setFixedExpenses] = useState<FixedExpense[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [categoryReport, setCategoryReport] = useState<CategoryReport[]>([]);
  const [fixedHistory, setFixedHistory] = useState<FixedExpenseHistory[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [vaquinhas, setVaquinhas] = useState<Vaquinha[]>([]);
  const [billReminders, setBillReminders] = useState<BillReminder[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddFixed, setShowAddFixed] = useState(false);
  const [showAddTransaction, setShowAddTransaction] = useState(false);
  const [showAddPatient, setShowAddPatient] = useState(false);
  const [showAddVaquinha, setShowAddVaquinha] = useState(false);
  const [showAddBillReminder, setShowAddBillReminder] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [selectedReceipt, setSelectedReceipt] = useState<string | null>(null);
  const [viewingPatientId, setViewingPatientId] = useState<number | null>(null);
  const [selectedBillReminder, setSelectedBillReminder] = useState<BillReminder | null>(null);
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
  const [confirmModal, setConfirmModal] = useState<{
    show: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  } | null>(null);

  const currentMonth = new Date().getMonth() + 1;
  const currentYear = new Date().getFullYear();

  const safeFetch = async (url: string, options?: RequestInit) => {
    const res = await window.fetch(url, options);
    if (res.status === 401) {
      setUser(null);
      throw new Error('Sessão expirada');
    }
    if (!res.ok) {
      const text = await res.text();
      let errorMessage = `Erro HTTP! status: ${res.status}`;
      try {
        const errorJson = JSON.parse(text);
        errorMessage = errorJson.message || errorJson.error || errorMessage;
      } catch (e) {
        errorMessage = text.substring(0, 100) || errorMessage;
      }
      throw new Error(errorMessage);
    }
    const contentType = res.headers.get("content-type");
    if (contentType && contentType.includes("application/json")) {
      return await res.json();
    }
    return await res.text();
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      const [statsData, fixedData, transData, reportData, historyData, patientsData, vaquinhasData, remindersData] = await Promise.all([
        safeFetch(`/api/dashboard?month=${currentMonth}&year=${currentYear}`),
        safeFetch(`/api/fixed-expenses?month=${currentMonth}&year=${currentYear}`),
        safeFetch('/api/transactions'),
        safeFetch(`/api/reports/category?month=${currentMonth}&year=${currentYear}`),
        safeFetch('/api/reports/fixed-expenses-history'),
        safeFetch('/api/patients'),
        safeFetch('/api/vaquinhas'),
        safeFetch(`/api/bill-reminders?month=${currentMonth}&year=${currentYear}`)
      ]);

      setStats(statsData);
      setFixedExpenses(fixedData);
      setTransactions(transData);
      setCategoryReport(reportData);
      setFixedHistory(historyData);
      setPatients(patientsData);
      setVaquinhas(vaquinhasData);
      setBillReminders(remindersData);
    } catch (err) {
      console.error("Fetch error:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const userData = await safeFetch('/api/auth/me');
        setUser(userData);
      } catch (err) {
        // Not logged in
      } finally {
        setLoading(false);
      }
    };
    checkAuth();
  }, []);

  useEffect(() => {
    if (user) {
      fetchData();
    }
  }, [user, activeTab]);

  const handlePayFixed = async (id: number) => {
    try {
      await safeFetch(`/api/fixed-expenses/${id}/pay`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ month: currentMonth, year: currentYear })
      });
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleAddFixed = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = Object.fromEntries(formData.entries());
    try {
      await safeFetch('/api/fixed-expenses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      setShowAddFixed(false);
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleAddTransaction = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const url = selectedTransaction ? `/api/transactions/${selectedTransaction.id}` : '/api/transactions';
    const method = selectedTransaction ? 'PUT' : 'POST';

    try {
      await safeFetch(url, {
        method,
        body: formData
      });
      setShowAddTransaction(false);
      setSelectedTransaction(null);
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteTransaction = async (id: number) => {
    setConfirmModal({
      show: true,
      title: 'Excluir Transação',
      message: 'Tem certeza que deseja excluir esta transação?',
      onConfirm: async () => {
        try {
          await safeFetch(`/api/transactions/${id}`, { method: 'DELETE' });
          fetchData();
          setConfirmModal(null);
        } catch (err) {
          console.error(err);
        }
      }
    });
  };

  const handleDeleteFixedExpense = async (id: number) => {
    setConfirmModal({
      show: true,
      title: 'Excluir Despesa Fixa',
      message: 'Tem certeza que deseja excluir esta despesa fixa?',
      onConfirm: async () => {
        try {
          await safeFetch(`/api/fixed-expenses/${id}`, { method: 'DELETE' });
          fetchData();
          setConfirmModal(null);
        } catch (err) {
          console.error(err);
        }
      }
    });
  };

  const handleAddPatient = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = Object.fromEntries(formData.entries());
    
    const url = selectedPatient ? `/api/patients/${selectedPatient.id}` : '/api/patients';
    const method = selectedPatient ? 'PUT' : 'POST';

    try {
      await safeFetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      setShowAddPatient(false);
      setSelectedPatient(null);
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeletePatient = (id: number) => {
    setConfirmModal({
      show: true,
      title: 'Excluir Paciente',
      message: 'Tem certeza que deseja excluir este paciente?',
      onConfirm: async () => {
        try {
          await safeFetch(`/api/patients/${id}`, { method: 'DELETE' });
          fetchData();
          setConfirmModal(null);
        } catch (err) {
          console.error(err);
        }
      }
    });
  };

  const handleUploadDocument = async (e: React.FormEvent<HTMLFormElement>, patientId: number) => {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);
    try {
      await safeFetch(`/api/patients/${patientId}/documents`, {
        method: 'POST',
        body: formData
      });
      form.reset();
      fetchData();
    } catch (err) {
      console.error('Upload error:', err);
    }
  };

  const handleAddVaquinha = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = Object.fromEntries(formData.entries());
    try {
      await safeFetch('/api/vaquinhas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      setShowAddVaquinha(false);
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteVaquinha = async (id: number) => {
    setConfirmModal({
      show: true,
      title: 'Excluir Vaquinha',
      message: 'Tem certeza que deseja excluir esta vaquinha?',
      onConfirm: async () => {
        try {
          await safeFetch(`/api/vaquinhas/${id}`, { method: 'DELETE' });
          fetchData();
          setConfirmModal(null);
        } catch (err) {
          console.error(err);
        }
      }
    });
  };

  const handleAddBillReminder = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = Object.fromEntries(formData.entries());
    
    // Ensure month is in MM/YYYY format
    const monthYear = `${currentMonth.toString().padStart(2, '0')}/${currentYear}`;
    const payload = { ...data, month: monthYear, amount: parseFloat(data.amount as string) };

    const url = selectedBillReminder ? `/api/bill-reminders/${selectedBillReminder.id}` : '/api/bill-reminders';
    const method = selectedBillReminder ? 'PUT' : 'POST';

    try {
      await safeFetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      setShowAddBillReminder(false);
      setSelectedBillReminder(null);
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleToggleBillStatus = async (reminder: BillReminder) => {
    const newStatus = reminder.status === 'Pendente' ? 'Enviado' : 'Pendente';
    try {
      await safeFetch(`/api/bill-reminders/${reminder.id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteBillReminder = async (id: number) => {
    setConfirmModal({
      show: true,
      title: 'Excluir Lembrete',
      message: 'Tem certeza que deseja excluir este lembrete?',
      onConfirm: async () => {
        try {
          await safeFetch(`/api/bill-reminders/${id}`, { method: 'DELETE' });
          fetchData();
          setConfirmModal(null);
        } catch (err) {
          console.error(err);
        }
      }
    });
  };

  const generateWhatsAppMessage = (vaquinha: Vaquinha) => {
    const text = `Olá! Estamos realizando uma vaquinha: *${vaquinha.title}*.\n\n${vaquinha.description}\n\nMeta: ${formatCurrency(vaquinha.goal_amount)}\nChave PIX: *${vaquinha.pix_key}*\n\nSua ajuda é muito importante!`;
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  if (loading && !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black/5">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    );
  }

  if (!user) {
    return <Login onLogin={(u) => setUser(u)} />;
  }

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-[#F8F9FA] text-black font-sans">
      {/* Sidebar */}
      <aside className="fixed left-0 top-0 bottom-0 w-64 bg-white border-r border-black/5 p-6 z-40 hidden md:block">
        <div className="flex items-center gap-3 mb-12 px-2">
          <div className="w-10 h-10 bg-black rounded-xl flex items-center justify-center">
            <Wallet className="text-white w-6 h-6" />
          </div>
          <h1 className="font-bold text-xl tracking-tight">FinTrack</h1>
        </div>

        <nav className="space-y-2">
          {[
            { id: 'dashboard', label: 'Painel', icon: LayoutDashboard },
            { id: 'patients', label: 'Pacientes', icon: Users },
            { id: 'vaquinhas', label: 'Vaquinhas', icon: Heart },
            { id: 'financial', label: 'Financeiro', icon: Wallet },
            { id: 'reports', label: 'Relatórios', icon: BarChart3 },
            ...(user.role === 'Admin' ? [{ id: 'users', label: 'Usuários', icon: Users }] : []),
            { id: 'settings', label: 'Configurações', icon: SettingsIcon },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium",
                activeTab === item.id 
                  ? "bg-black text-white shadow-lg shadow-black/10" 
                  : "text-black/50 hover:bg-black/5 hover:text-black"
              )}
            >
              <item.icon size={20} />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="absolute bottom-6 left-6 right-6 space-y-4">
          <div className="flex items-center gap-3 p-3 bg-black/5 rounded-2xl">
            <div className="w-10 h-10 bg-black/10 rounded-xl flex items-center justify-center font-bold">
              {user.name.charAt(0)}
            </div>
            <div className="flex-1 overflow-hidden">
              <p className="text-sm font-bold truncate">{user.name}</p>
              <p className="text-[10px] text-black/40 font-bold uppercase">{user.role}</p>
            </div>
          </div>
          <Button variant="secondary" className="w-full text-xs py-2" onClick={async () => {
            await window.fetch('/api/auth/logout', { method: 'POST' });
            setUser(null);
          }}>
            Sair do Sistema
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="md:ml-64 p-4 md:p-8 pb-24">
        <header className="flex justify-between items-center mb-8">
          <div>
            <h2 className="text-3xl font-bold tracking-tight capitalize">
              {activeTab === 'dashboard' ? 'Painel' : 
               activeTab === 'patients' ? 'Pacientes' : 
               activeTab === 'vaquinhas' ? 'Vaquinhas' : 
               activeTab === 'financial' ? 'Financeiro' : 
               activeTab === 'reports' ? 'Relatórios' : 
               activeTab === 'users' ? 'Usuários' : 'Configurações'}
            </h2>
            <p className="text-black/40 font-medium">{format(new Date(), 'MMMM yyyy', { locale: ptBR })}</p>
          </div>
          <div className="flex gap-3">
            {activeTab === 'patients' && (
              <Button onClick={() => { setSelectedPatient(null); setShowAddPatient(true); }}>
                <Plus size={18} /> Adicionar Paciente
              </Button>
            )}
            {activeTab === 'vaquinhas' && (
              <Button onClick={() => setShowAddVaquinha(true)}>
                <Plus size={18} /> Nova Vaquinha
              </Button>
            )}
            {activeTab === 'financial' && (
              <div className="flex gap-2">
                <Button variant="secondary" onClick={() => setShowAddFixed(true)}>
                  <Plus size={18} /> Despesa Fixa
                </Button>
                <Button onClick={() => setShowAddTransaction(true)}>
                  <Plus size={18} /> Transação
                </Button>
              </div>
            )}
          </div>
        </header>

        <AnimatePresence mode="wait">
          {activeTab === 'dashboard' && (
            <motion.div 
              key="dashboard"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              {/* Stats Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
                      <TrendingUp size={20} />
                    </div>
                  </div>
                  <p className="text-xs font-bold uppercase tracking-widest text-black/40 mb-1">Receita Mensal</p>
                  <h3 className="text-2xl font-bold">{formatCurrency(stats?.monthlyIncome || 0)}</h3>
                </Card>
                <Card className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div className="p-2 bg-red-50 text-red-600 rounded-lg">
                      <TrendingDown size={20} />
                    </div>
                  </div>
                  <p className="text-xs font-bold uppercase tracking-widest text-black/40 mb-1">Despesas Mensais</p>
                  <h3 className="text-2xl font-bold">{formatCurrency(stats?.monthlyExpenses || 0)}</h3>
                </Card>
                <Card className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                      <CalendarClock size={20} />
                    </div>
                  </div>
                  <p className="text-xs font-bold uppercase tracking-widest text-black/40 mb-1">Contas Fixas</p>
                  <h3 className="text-2xl font-bold">{formatCurrency(stats?.fixedExpensesTotal || 0)}</h3>
                </Card>
                <Card className="p-6 bg-black text-white">
                  <div className="flex justify-between items-start mb-4">
                    <div className="p-2 bg-white/10 text-white rounded-lg">
                      <Wallet size={20} />
                    </div>
                  </div>
                  <p className="text-xs font-bold uppercase tracking-widest text-white/40 mb-1">Saldo Restante</p>
                  <h3 className="text-2xl font-bold">{formatCurrency(stats?.remainingBalance || 0)}</h3>
                </Card>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <Card className="lg:col-span-2 p-6">
                  <h4 className="font-bold mb-4">Pacientes Recentes</h4>
                  <div className="space-y-4">
                    {patients.slice(0, 5).map(p => (
                      <div key={p.id} className="flex items-center justify-between p-3 rounded-xl bg-black/[0.02]">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-black/5 rounded-full flex items-center justify-center font-bold text-black/40">
                            {p.full_name.charAt(0)}
                          </div>
                          <div>
                            <p className="font-bold text-sm">{p.full_name}</p>
                            <p className="text-xs text-black/40">{p.city} • {p.status}</p>
                          </div>
                        </div>
                        <Button variant="ghost" className="text-xs" onClick={() => { setViewingPatientId(p.id); setActiveTab('patients'); }}>Ver Perfil</Button>
                      </div>
                    ))}
                    {patients.length === 0 && <p className="text-center text-black/30 py-8">Nenhum paciente cadastrado.</p>}
                  </div>
                </Card>
                <Card className="p-6">
                  <h4 className="font-bold mb-4">Vaquinhas Ativas</h4>
                  <div className="space-y-4">
                    {vaquinhas.filter(v => v.status === 'Aberta').slice(0, 3).map(v => (
                      <div key={v.id} className="p-4 rounded-xl border border-black/5 bg-black/[0.01]">
                        <p className="font-bold text-sm mb-1">{v.title}</p>
                        <div className="flex justify-between text-xs mb-2">
                          <span className="text-black/40">Meta: {formatCurrency(v.goal_amount)}</span>
                          <span className="font-bold text-emerald-600">{Math.round((v.current_amount / v.goal_amount) * 100)}%</span>
                        </div>
                        <div className="w-full bg-black/5 h-1.5 rounded-full overflow-hidden">
                          <div className="bg-emerald-500 h-full" style={{ width: `${(v.current_amount / v.goal_amount) * 100}%` }} />
                        </div>
                      </div>
                    ))}
                    {vaquinhas.length === 0 && <p className="text-center text-black/30 py-8">Nenhuma vaquinha ativa.</p>}
                  </div>
                </Card>
              </div>
            </motion.div>
          )}

          {activeTab === 'patients' && (
            <motion.div 
              key="patients"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              {viewingPatientId ? (
                <div className="space-y-6">
                  <Button variant="ghost" onClick={() => setViewingPatientId(null)} className="mb-4">
                    <ChevronLeft size={18} /> Voltar para Lista
                  </Button>
                  {(() => {
                    const patient = patients.find(p => p.id === viewingPatientId);
                    if (!patient) return null;
                    return (
                      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        <Card className="lg:col-span-2 p-8">
                          <div className="flex justify-between items-start mb-8">
                            <div className="flex items-center gap-6">
                              <div className="w-20 h-20 bg-black text-white rounded-3xl flex items-center justify-center text-3xl font-bold">
                                {patient.full_name.charAt(0)}
                              </div>
                              <div>
                                <h3 className="text-2xl font-bold">{patient.full_name}</h3>
                                <p className="text-black/40 font-medium">{patient.city}, {patient.state}</p>
                                <span className={cn(
                                  "inline-block mt-2 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider",
                                  patient.status === 'Ativo' ? "bg-emerald-50 text-emerald-600" : "bg-black/5 text-black/40"
                                )}>
                                  {patient.status}
                                </span>
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <Button variant="secondary" onClick={() => { setSelectedPatient(patient); setShowAddPatient(true); }}>Editar</Button>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                            <div className="space-y-4">
                              <div>
                                <p className="text-xs font-bold text-black/30 uppercase tracking-widest mb-1">Data de Nascimento</p>
                                <p className="font-medium">{patient.dob ? format(parseISO(patient.dob), 'dd/MM/yyyy') : '-'}</p>
                              </div>
                              <div>
                                <p className="text-xs font-bold text-black/30 uppercase tracking-widest mb-1">CPF / RG</p>
                                <p className="font-medium">{patient.cpf_id || '-'}</p>
                              </div>
                              <div>
                                <p className="text-xs font-bold text-black/30 uppercase tracking-widest mb-1">Telefone</p>
                                <p className="font-medium">{patient.phone || '-'}</p>
                              </div>
                              <div>
                                <p className="text-xs font-bold text-black/30 uppercase tracking-widest mb-1">Endereço</p>
                                <p className="font-medium">{patient.address || '-'}</p>
                              </div>
                            </div>
                            <div className="space-y-4">
                              <div>
                                <p className="text-xs font-bold text-black/30 uppercase tracking-widest mb-1">Responsável</p>
                                <p className="font-medium">{patient.responsible_person || '-'}</p>
                              </div>
                              <div>
                                <p className="text-xs font-bold text-black/30 uppercase tracking-widest mb-1">Contato Responsável</p>
                                <p className="font-medium">{patient.responsible_contact || '-'}</p>
                              </div>
                              <div>
                                <p className="text-xs font-bold text-black/30 uppercase tracking-widest mb-1">Data de Entrada</p>
                                <p className="font-medium">{patient.entry_date ? format(parseISO(patient.entry_date), 'dd/MM/yyyy') : '-'}</p>
                              </div>
                            </div>
                          </div>

                          <div className="pt-8 border-t border-black/5">
                            <p className="text-xs font-bold text-black/30 uppercase tracking-widest mb-2">Observações Médicas</p>
                            <div className="p-4 bg-black/[0.02] rounded-2xl text-sm leading-relaxed text-black/70">
                              {patient.medical_observations || 'Nenhuma observação registrada.'}
                            </div>
                          </div>
                        </Card>

                        <div className="space-y-8">
                          <Card className="p-6">
                            <h4 className="font-bold mb-4 flex items-center gap-2">
                              <FileText size={18} /> Documentos
                            </h4>
                            <form onSubmit={(e) => handleUploadDocument(e, patient.id)} className="mb-6">
                              <div className="relative mb-3">
                                <input type="file" name="document" className="hidden" id="doc-upload" required />
                                <label 
                                  htmlFor="doc-upload"
                                  className="w-full flex items-center justify-center gap-2 px-4 py-4 border-2 border-dashed border-black/10 rounded-xl hover:border-black/20 hover:bg-black/[0.02] cursor-pointer transition-all"
                                >
                                  <Upload size={16} className="text-black/40" />
                                  <span className="text-xs font-medium text-black/60">Selecionar Arquivo</span>
                                </label>
                              </div>
                              <Input name="name" placeholder="Nome do documento" className="text-xs mb-3" />
                              <Button type="submit" className="w-full text-xs py-2">Fazer Upload</Button>
                            </form>

                            <div className="space-y-2">
                              {patient.documents && patient.documents.length > 0 ? (
                                patient.documents.map((doc) => (
                                  <div key={doc.id} className="flex items-center justify-between p-3 rounded-xl bg-black/[0.02] border border-black/5">
                                    <div className="flex items-center gap-3">
                                      <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                                        <FileText size={16} />
                                      </div>
                                      <div>
                                        <p className="text-xs font-bold truncate max-w-[120px]">{doc.name}</p>
                                        <p className="text-[10px] text-black/40">{format(parseISO(doc.uploaded_at), 'dd/MM/yy HH:mm')}</p>
                                      </div>
                                    </div>
                                    <div className="flex gap-1">
                                      <a 
                                        href={doc.file_path} 
                                        target="_blank" 
                                        rel="noopener noreferrer"
                                        className="p-1.5 text-black/40 hover:text-black hover:bg-black/5 rounded-lg transition-all"
                                      >
                                        <Eye size={14} />
                                      </a>
                                      <button 
                                        onClick={() => {
                                          setConfirmModal({
                                            show: true,
                                            title: 'Excluir Documento',
                                            message: 'Tem certeza que deseja excluir este documento?',
                                            onConfirm: async () => {
                                              try {
                                                await safeFetch(`/api/documents/${doc.id}`, { method: 'DELETE' });
                                                fetchData();
                                                setConfirmModal(null);
                                              } catch (err) {
                                                console.error(err);
                                              }
                                            }
                                          });
                                        }}
                                        className="p-1.5 text-black/20 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                                      >
                                        <Trash2 size={14} />
                                      </button>
                                    </div>
                                  </div>
                                ))
                              ) : (
                                <p className="text-center text-xs text-black/30 py-4">Nenhum documento anexado.</p>
                              )}
                            </div>
                          </Card>

                          <Card className="p-6">
                            <h4 className="font-bold mb-4 flex items-center gap-2">
                              <CalendarClock size={18} /> Histórico de Entrada
                            </h4>
                            <div className="space-y-4">
                              <div className="flex gap-3">
                                <div className="w-2 h-2 rounded-full bg-emerald-500 mt-1.5" />
                                <div>
                                  <p className="text-sm font-bold">Entrada no Sistema</p>
                                  <p className="text-xs text-black/40">{patient.entry_date ? format(parseISO(patient.entry_date), 'dd/MM/yyyy') : '-'}</p>
                                </div>
                              </div>
                              {patient.exit_date && (
                                <div className="flex gap-3">
                                  <div className="w-2 h-2 rounded-full bg-black/20 mt-1.5" />
                                  <div>
                                    <p className="text-sm font-bold">Saída / Alta</p>
                                    <p className="text-xs text-black/40">{format(parseISO(patient.exit_date), 'dd/MM/yyyy')}</p>
                                  </div>
                                </div>
                              )}
                            </div>
                          </Card>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              ) : (
                <Card>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-black/5 bg-black/[0.02]">
                          <th className="p-4 text-xs font-bold uppercase tracking-widest text-black/40">Nome Completo</th>
                          <th className="p-4 text-xs font-bold uppercase tracking-widest text-black/40">Telefone</th>
                          <th className="p-4 text-xs font-bold uppercase tracking-widest text-black/40">Cidade</th>
                          <th className="p-4 text-xs font-bold uppercase tracking-widest text-black/40">Entrada</th>
                          <th className="p-4 text-xs font-bold uppercase tracking-widest text-black/40">Status</th>
                          <th className="p-4 text-xs font-bold uppercase tracking-widest text-black/40 text-right">Ações</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-black/5">
                        {patients.map((p) => (
                          <tr key={p.id} className="hover:bg-black/[0.01] transition-colors group">
                            <td className="p-4">
                              <p className="text-sm font-bold">{p.full_name}</p>
                            </td>
                            <td className="p-4 text-sm text-black/60">{p.phone || '-'}</td>
                            <td className="p-4 text-sm text-black/60">{p.city || '-'}</td>
                            <td className="p-4 text-sm text-black/60">{p.entry_date ? format(parseISO(p.entry_date), 'dd/MM/yyyy') : '-'}</td>
                            <td className="p-4">
                              <span className={cn(
                                "px-2 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider",
                                p.status === 'Ativo' ? "bg-emerald-50 text-emerald-600" : "bg-black/5 text-black/40"
                              )}>
                                {p.status}
                              </span>
                            </td>
                            <td className="p-4 text-right">
                              <div className="flex justify-end gap-2">
                                <button onClick={() => setViewingPatientId(p.id)} className="p-2 text-black/40 hover:text-black hover:bg-black/5 rounded-lg transition-all"><Eye size={18} /></button>
                                <button onClick={() => { setSelectedPatient(p); setShowAddPatient(true); }} className="p-2 text-black/40 hover:text-black hover:bg-black/5 rounded-lg transition-all"><FileText size={18} /></button>
                                <button onClick={() => handleDeletePatient(p.id)} className="p-2 text-black/40 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"><Trash2 size={18} /></button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {patients.length === 0 && (
                      <div className="p-20 text-center text-black/30">
                        <Users className="mx-auto mb-4 opacity-20" size={48} />
                        <p>Nenhum paciente cadastrado ainda.</p>
                      </div>
                    )}
                  </div>
                </Card>
              )}
            </motion.div>
          )}

          {activeTab === 'vaquinhas' && (
            <motion.div 
              key="vaquinhas"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {vaquinhas.map((v) => (
                  <Card key={v.id} className="p-6 flex flex-col h-full">
                    <div className="flex justify-between items-start mb-4">
                      <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
                        <Heart size={20} />
                      </div>
                      <div className="flex gap-2">
                        <span className={cn(
                          "px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                          v.status === 'Aberta' ? "bg-emerald-50 text-emerald-600" : "bg-black/5 text-black/40"
                        )}>
                          {v.status}
                        </span>
                        <button 
                          onClick={() => handleDeleteVaquinha(v.id)}
                          className="p-1 text-black/20 hover:text-red-500 transition-colors"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                    <h4 className="font-bold text-lg mb-2">{v.title}</h4>
                    <p className="text-sm text-black/50 mb-6 flex-grow line-clamp-3">{v.description}</p>
                    
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-xs font-bold mb-2">
                          <span className="text-black/40 uppercase tracking-widest">Progresso</span>
                          <span className="text-emerald-600">{formatCurrency(v.current_amount)} / {formatCurrency(v.goal_amount)}</span>
                        </div>
                        <div className="w-full bg-black/5 h-2 rounded-full overflow-hidden">
                          <div 
                            className="bg-emerald-500 h-full transition-all duration-1000" 
                            style={{ width: `${Math.min((v.current_amount / v.goal_amount) * 100, 100)}%` }} 
                          />
                        </div>
                      </div>

                      <div className="p-3 bg-black/[0.02] rounded-xl border border-black/5">
                        <p className="text-[10px] font-bold text-black/30 uppercase tracking-widest mb-1">Chave PIX</p>
                        <p className="text-sm font-mono font-bold break-all">{v.pix_key}</p>
                      </div>

                      <div className="flex gap-2 pt-2">
                        <Button className="flex-1 text-xs" onClick={() => generateWhatsAppMessage(v)}>
                          <MessageCircle size={16} /> Compartilhar
                        </Button>
                        <Button variant="secondary" className="p-2" onClick={() => {
                          const amount = prompt('Valor arrecadado:', '0');
                          if (amount) {
                            safeFetch(`/api/vaquinhas/${v.id}`, {
                              method: 'PUT',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify({ ...v, current_amount: v.current_amount + parseFloat(amount) })
                            }).then(() => fetchData()).catch(err => console.error(err));
                          }
                        }}>
                          <Plus size={16} />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
                {vaquinhas.length === 0 && (
                  <div className="col-span-full p-20 text-center text-black/30 bg-white rounded-3xl border border-black/5">
                    <Heart className="mx-auto mb-4 opacity-20" size={48} />
                    <p>Nenhuma vaquinha criada ainda.</p>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {activeTab === 'financial' && (
            <motion.div 
              key="financial"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="flex gap-4 border-b border-black/5 pb-1">
                <button 
                  onClick={() => setActiveTab('financial')} 
                  className={cn("pb-3 px-4 text-sm font-bold transition-all border-b-2", activeTab === 'financial' ? "border-black text-black" : "border-transparent text-black/40")}
                >
                  Transações
                </button>
              </div>

              <div className="space-y-8">
                <section className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-bold flex items-center gap-2">
                      <Bell size={20} className="text-blue-600" /> Lembrete de Contas Mensais (Prefeitura)
                    </h3>
                    <Button onClick={() => setShowAddBillReminder(true)} className="text-xs py-1.5 h-auto">
                      <Plus size={14} /> Novo Lembrete
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {billReminders.map((reminder) => {
                      const isNearDue = reminder.due_date && isAfter(new Date(), parseISO(reminder.due_date));
                      return (
                        <Card key={reminder.id} className={cn(
                          "p-4 border-l-4",
                          reminder.status === 'Enviado' ? "border-l-emerald-500 opacity-60" : 
                          isNearDue ? "border-l-red-500 bg-red-50/30" : "border-l-blue-500"
                        )}>
                          <div className="flex justify-between items-start mb-2">
                            <h4 className="font-bold text-sm">{reminder.name}</h4>
                            <div className="flex gap-1">
                              <button onClick={() => { setSelectedBillReminder(reminder); setShowAddBillReminder(true); }} className="p-1 text-black/20 hover:text-black"><Eye size={14} /></button>
                              <button onClick={() => handleDeleteBillReminder(reminder.id)} className="p-1 text-black/20 hover:text-red-500"><Trash2 size={14} /></button>
                            </div>
                          </div>
                          <div className="space-y-2">
                            <div className="flex justify-between items-center">
                              <span className="text-[10px] text-black/40 uppercase font-bold">Valor</span>
                              <span className="text-sm font-bold">{formatCurrency(reminder.amount)}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-[10px] text-black/40 uppercase font-bold">Vencimento</span>
                              <span className={cn("text-xs font-medium", isNearDue && reminder.status === 'Pendente' ? "text-red-600" : "text-black/60")}>
                                {reminder.due_date ? format(parseISO(reminder.due_date), 'dd/MM/yyyy') : '-'}
                              </span>
                            </div>
                            <button 
                              onClick={() => handleToggleBillStatus(reminder)}
                              className={cn(
                                "w-full py-2 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-2",
                                reminder.status === 'Enviado' ? "bg-emerald-50 text-emerald-600" : "bg-blue-50 text-blue-600 hover:bg-blue-100"
                              )}
                            >
                              {reminder.status === 'Enviado' ? (
                                <><CheckCircle2 size={12} /> Enviado à Prefeitura</>
                              ) : (
                                <><Send size={12} /> Marcar como Enviado</>
                              )}
                            </button>
                          </div>
                        </Card>
                      );
                    })}
                    {billReminders.length === 0 && (
                      <div className="col-span-full p-8 text-center text-black/30 bg-black/[0.01] rounded-2xl border border-dashed border-black/10">
                        <Clock className="mx-auto mb-2 opacity-20" size={32} />
                        <p className="text-xs">Nenhum lembrete para este mês.</p>
                      </div>
                    )}
                  </div>
                </section>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  <div className="lg:col-span-2 space-y-6">
                    <h3 className="text-lg font-bold flex items-center gap-2">
                      <Receipt size={20} className="text-emerald-600" /> Transações Financeiras
                    </h3>
                    <Card>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="border-b border-black/5 bg-black/[0.02]">
                            <th className="p-4 text-xs font-bold uppercase tracking-widest text-black/40">Data</th>
                            <th className="p-4 text-xs font-bold uppercase tracking-widest text-black/40">Descrição</th>
                            <th className="p-4 text-xs font-bold uppercase tracking-widest text-black/40">Valor</th>
                            <th className="p-4 text-xs font-bold uppercase tracking-widest text-black/40 text-right">Ações</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-black/5">
                          {transactions.map((t) => (
                            <tr key={t.id} className="hover:bg-black/[0.01] transition-colors">
                              <td className="p-4 text-sm">{format(parseISO(t.date), 'dd/MM/yy')}</td>
                              <td className="p-4">
                                <p className="text-sm font-bold">{t.description}</p>
                                <p className="text-[10px] text-black/40 uppercase font-bold tracking-wider">{t.category}</p>
                              </td>
                              <td className="p-4">
                                <span className={cn("font-bold", t.type === 'Receita' ? "text-emerald-600" : "text-black")}>
                                  {t.type === 'Receita' ? '+' : '-'}{formatCurrency(t.amount)}
                                </span>
                              </td>
                              <td className="p-4 text-right">
                                <div className="flex justify-end gap-2">
                                  {t.receipt_path && <button onClick={() => setSelectedReceipt(t.receipt_path)} className="p-2 text-black/40 hover:text-black"><Eye size={16} /></button>}
                                  <button onClick={() => { setSelectedTransaction(t); setShowAddTransaction(true); }} className="p-2 text-black/40 hover:text-black"><Pencil size={16} /></button>
                                  <button onClick={() => handleDeleteTransaction(t.id)} className="p-2 text-black/40 hover:text-red-500"><Trash2 size={16} /></button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </Card>
                </div>

                <div className="space-y-6">
                  <Card className="p-6">
                    <h4 className="font-bold mb-4">Despesas Fixas</h4>
                    <div className="space-y-3">
                      {fixedExpenses.map(e => (
                        <div key={e.id} className="p-3 rounded-xl bg-black/[0.02] border border-black/5 flex justify-between items-center">
                          <div>
                            <p className="text-sm font-bold">{e.name}</p>
                            <p className="text-[10px] text-black/40 uppercase font-bold">Dia {e.due_day}</p>
                          </div>
                          <div className="text-right flex flex-col items-end gap-1">
                            <div className="flex items-center gap-2">
                              <p className="text-sm font-bold">{formatCurrency(e.amount)}</p>
                              <button 
                                onClick={() => handleDeleteFixedExpense(e.id)} 
                                className="p-1 text-black/20 hover:text-red-500 transition-colors"
                                title="Excluir despesa fixa"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                            {e.status === 'Pendente' ? (
                              <button onClick={() => handlePayFixed(e.id)} className="text-[10px] font-bold text-blue-600 uppercase">Pagar</button>
                            ) : (
                              <span className="text-[10px] font-bold text-emerald-600 uppercase">Pago</span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </Card>
                </div>
              </div>
            </div>
          </motion.div>
          )}

          {activeTab === 'reports' && (
            <motion.div 
              key="reports"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="space-y-8"
            >
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <Card className="p-6">
                  <h4 className="font-bold mb-6">Despesas por Categoria</h4>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={categoryReport}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={80}
                          paddingAngle={5}
                          dataKey="total"
                          nameKey="category"
                        >
                          {categoryReport.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={['#000000', '#3B82F6', '#10B981', '#F59E0B', '#EF4444'][index % 5]} />
                          ))}
                        </Pie>
                        <Tooltip 
                          formatter={(value: number) => formatCurrency(value)}
                          contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="mt-4 space-y-2">
                    {categoryReport.map((item, i) => (
                      <div key={item.category} className="flex justify-between items-center text-sm">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: ['#000000', '#3B82F6', '#10B981', '#F59E0B', '#EF4444'][i % 5] }} />
                          <span className="font-medium">{item.category}</span>
                        </div>
                        <span className="font-bold">{formatCurrency(item.total)}</span>
                      </div>
                    ))}
                  </div>
                </Card>

                <Card className="p-6">
                  <h4 className="font-bold mb-6">Visão Geral Mensal</h4>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={[
                        { name: 'Receita', value: stats?.monthlyIncome || 0 },
                        { name: 'Despesas', value: stats?.monthlyExpenses || 0 },
                        { name: 'Fixas', value: stats?.fixedExpensesTotal || 0 }
                      ]}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#00000010" />
                        <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fontWeight: 600 }} />
                        <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fontWeight: 600 }} tickFormatter={(v) => `R$${v}`} />
                        <Tooltip 
                          cursor={{ fill: '#00000005' }}
                          formatter={(value: number) => formatCurrency(value)}
                          contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                        />
                        <Bar dataKey="value" radius={[6, 6, 0, 0]}>
                          { [0,1,2].map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={index === 0 ? '#10B981' : (index === 1 ? '#EF4444' : '#3B82F6')} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </Card>
              </div>

              <Card className="p-6">
                <h4 className="font-bold mb-6">Evolução de Despesas Fixas Pagas (6 Meses)</h4>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={fixedHistory}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#00000010" />
                      <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fontWeight: 600 }} />
                      <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fontWeight: 600 }} tickFormatter={(v) => `R$${v}`} />
                      <Tooltip 
                        cursor={{ fill: '#00000005' }}
                        formatter={(value: number) => formatCurrency(value)}
                        contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                      />
                      <Bar dataKey="total" fill="#3B82F6" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </Card>
            </motion.div>
          )}

          {activeTab === 'settings' && (
            <motion.div 
              key="settings"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <Card className="p-8 max-w-2xl">
                <h3 className="text-xl font-bold mb-6">Configurações do Sistema</h3>
                <div className="space-y-6">
                  <div className="p-4 bg-black/[0.02] rounded-2xl border border-black/5">
                    <h4 className="font-bold text-sm mb-2">Meu Perfil</h4>
                    <div className="space-y-4">
                      <Input label="Nome" defaultValue={user.name} disabled />
                      <Input label="Usuário" defaultValue={user.username} disabled />
                      <Input label="Nível de Acesso" defaultValue={user.role} disabled />
                    </div>
                  </div>
                  <div className="p-4 bg-black/[0.02] rounded-2xl border border-black/5">
                    <h4 className="font-bold text-sm mb-2">Backup e Dados</h4>
                    <p className="text-xs text-black/40 mb-4">Exporte todos os dados do sistema para um arquivo Excel ou PDF.</p>
                    <div className="flex gap-3">
                      <Button variant="secondary" className="text-xs"><Download size={16} /> Exportar Excel</Button>
                      <Button variant="secondary" className="text-xs"><FileText size={16} /> Relatório PDF</Button>
                    </div>
                  </div>
                </div>
              </Card>
            </motion.div>
          )}

          {activeTab === 'users' && user.role === 'Admin' && (
            <motion.div 
              key="users"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <UserManagement safeFetch={safeFetch} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Modals */}
      <AnimatePresence>
        {showAddFixed && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl"
            >
              <div className="p-6 border-b border-black/5 flex justify-between items-center">
                <h3 className="text-xl font-bold">Adicionar Despesa Fixa</h3>
                <button onClick={() => setShowAddFixed(false)} className="p-2 hover:bg-black/5 rounded-full"><X size={20} /></button>
              </div>
              <form onSubmit={handleAddFixed} className="p-6 space-y-4">
                <Input label="Nome" name="name" required placeholder="ex: Energia Elétrica" />
                <Input label="Descrição" name="description" placeholder="Conta de luz mensal" />
                <div className="grid grid-cols-2 gap-4">
                  <Input label="Valor" name="amount" type="number" step="0.01" required placeholder="0,00" />
                  <Input label="Dia de Vencimento" name="due_day" type="number" min="1" max="31" required placeholder="1-31" />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold uppercase tracking-wider text-black/50 ml-1">Notas</label>
                  <textarea name="notes" className="w-full px-4 py-2.5 bg-black/5 border border-transparent rounded-xl focus:bg-white focus:border-black/10 outline-none transition-all h-24 resize-none" />
                </div>
                <Button type="submit" className="w-full py-3">Criar Despesa</Button>
              </form>
            </motion.div>
          </div>
        )}

        {showAddTransaction && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl"
            >
              <div className="p-6 border-b border-black/5 flex justify-between items-center">
                <h3 className="text-xl font-bold">{selectedTransaction ? 'Editar Transação' : 'Nova Transação'}</h3>
                <button onClick={() => { setShowAddTransaction(false); setSelectedTransaction(null); }} className="p-2 hover:bg-black/5 rounded-full"><X size={20} /></button>
              </div>
              <form onSubmit={handleAddTransaction} className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <Input label="Data" name="date" type="date" required defaultValue={selectedTransaction?.date || format(new Date(), 'yyyy-MM-dd')} />
                  <Select label="Tipo" name="type" required defaultValue={selectedTransaction?.type || 'Despesa'} options={[
                    { value: 'Despesa', label: 'Despesa' },
                    { value: 'Receita', label: 'Receita' }
                  ]} />
                </div>
                <Input label="Descrição" name="description" required defaultValue={selectedTransaction?.description} placeholder="O que foi isso?" />
                <div className="grid grid-cols-2 gap-4">
                  <Input label="Valor" name="amount" type="number" step="0.01" required defaultValue={selectedTransaction?.amount} placeholder="0,00" />
                  <Input label="Categoria" name="category" required defaultValue={selectedTransaction?.category} placeholder="ex: Alimentação, Aluguel" />
                </div>
                <Input label="Método de Pagamento" name="payment_method" defaultValue={selectedTransaction?.payment_method} placeholder="ex: Cartão de Crédito, Dinheiro" />
                
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold uppercase tracking-wider text-black/50 ml-1">Comprovante (Foto/PDF)</label>
                  <div className="relative">
                    <input type="file" name="receipt" accept="image/*,application/pdf" className="hidden" id="receipt-upload" />
                    <label 
                      htmlFor="receipt-upload"
                      className="w-full flex items-center justify-center gap-2 px-4 py-8 border-2 border-dashed border-black/10 rounded-2xl hover:border-black/20 hover:bg-black/[0.02] cursor-pointer transition-all"
                    >
                      <Upload size={20} className="text-black/40" />
                      <span className="text-sm font-medium text-black/60">
                        {selectedTransaction?.receipt_path ? 'Mudar comprovante' : 'Clique para enviar comprovante'}
                      </span>
                    </label>
                  </div>
                </div>

                <Button type="submit" className="w-full py-3">
                  {selectedTransaction ? 'Salvar Alterações' : 'Salvar Transação'}
                </Button>
              </form>
            </motion.div>
          </div>
        )}

        {showAddPatient && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl"
            >
              <div className="p-6 border-b border-black/5 flex justify-between items-center">
                <h3 className="text-xl font-bold">{selectedPatient ? 'Editar Paciente' : 'Novo Paciente'}</h3>
                <button onClick={() => { setShowAddPatient(false); setSelectedPatient(null); }} className="p-2 hover:bg-black/5 rounded-full"><X size={20} /></button>
              </div>
              <form onSubmit={handleAddPatient} className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input label="Nome Completo" name="full_name" required defaultValue={selectedPatient?.full_name} />
                  <Input label="Data de Nascimento" name="dob" type="date" defaultValue={selectedPatient?.dob} />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input label="CPF / RG" name="cpf_id" defaultValue={selectedPatient?.cpf_id} />
                  <Input label="Telefone" name="phone" defaultValue={selectedPatient?.phone} />
                </div>
                <Input label="Endereço" name="address" defaultValue={selectedPatient?.address} />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input label="Cidade" name="city" defaultValue={selectedPatient?.city} />
                  <Input label="Estado" name="state" defaultValue={selectedPatient?.state} />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input label="Responsável" name="responsible_person" defaultValue={selectedPatient?.responsible_person} />
                  <Input label="Contato Responsável" name="responsible_contact" defaultValue={selectedPatient?.responsible_contact} />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input label="Data de Entrada" name="entry_date" type="date" defaultValue={selectedPatient?.entry_date || format(new Date(), 'yyyy-MM-dd')} />
                  <Input label="Data de Saída" name="exit_date" type="date" defaultValue={selectedPatient?.exit_date} />
                </div>
                <Select label="Status" name="status" defaultValue={selectedPatient?.status || 'Ativo'} options={[
                  { value: 'Ativo', label: 'Ativo' },
                  { value: 'Alta', label: 'Alta' }
                ]} />
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold uppercase tracking-wider text-black/50 ml-1">Observações Médicas</label>
                  <textarea name="medical_observations" defaultValue={selectedPatient?.medical_observations} className="w-full px-4 py-2.5 bg-black/5 border border-transparent rounded-xl focus:bg-white focus:border-black/10 outline-none transition-all h-32 resize-none" />
                </div>
                <Button type="submit" className="w-full py-3">Salvar Paciente</Button>
              </form>
            </motion.div>
          </div>
        )}

        {showAddVaquinha && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl"
            >
              <div className="p-6 border-b border-black/5 flex justify-between items-center">
                <h3 className="text-xl font-bold">Nova Vaquinha</h3>
                <button onClick={() => setShowAddVaquinha(false)} className="p-2 hover:bg-black/5 rounded-full"><X size={20} /></button>
              </div>
              <form onSubmit={handleAddVaquinha} className="p-6 space-y-4">
                <Input label="Título" name="title" required placeholder="ex: Reforma da Cozinha" />
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold uppercase tracking-wider text-black/50 ml-1">Descrição</label>
                  <textarea name="description" required className="w-full px-4 py-2.5 bg-black/5 border border-transparent rounded-xl focus:bg-white focus:border-black/10 outline-none transition-all h-24 resize-none" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <Input label="Meta (R$)" name="goal_amount" type="number" step="0.01" required placeholder="0,00" />
                  <Input label="Chave PIX" name="pix_key" required placeholder="CPF, E-mail, etc" />
                </div>
                <Button type="submit" className="w-full py-3">Criar Vaquinha</Button>
              </form>
            </motion.div>
          </div>
        )}

        {showAddBillReminder && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl"
            >
              <div className="p-6 border-b border-black/5 flex justify-between items-center">
                <h3 className="text-xl font-bold">{selectedBillReminder ? 'Editar Lembrete' : 'Novo Lembrete de Conta'}</h3>
                <button onClick={() => { setShowAddBillReminder(false); setSelectedBillReminder(null); }} className="p-2 hover:bg-black/5 rounded-full"><X size={20} /></button>
              </div>
              <form onSubmit={handleAddBillReminder} className="p-6 space-y-4">
                <Input label="Nome da Conta" name="name" required defaultValue={selectedBillReminder?.name} placeholder="ex: Conta de Luz" />
                <div className="grid grid-cols-2 gap-4">
                  <Input label="Valor (R$)" name="amount" type="number" step="0.01" required defaultValue={selectedBillReminder?.amount} placeholder="0,00" />
                  <Input label="Data de Vencimento" name="due_date" type="date" required defaultValue={selectedBillReminder?.due_date} />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold uppercase tracking-wider text-black/50 ml-1">Observações</label>
                  <textarea name="notes" defaultValue={selectedBillReminder?.notes} className="w-full px-4 py-2.5 bg-black/5 border border-transparent rounded-xl focus:bg-white focus:border-black/10 outline-none transition-all h-24 resize-none" />
                </div>
                <Button type="submit" className="w-full py-3">{selectedBillReminder ? 'Salvar Alterações' : 'Criar Lembrete'}</Button>
              </form>
            </motion.div>
          </div>
        )}

        {selectedReceipt && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-[60] flex items-center justify-center p-4" onClick={() => setSelectedReceipt(null)}>
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="relative max-w-4xl w-full h-[80vh] bg-white rounded-3xl overflow-hidden shadow-2xl"
              onClick={e => e.stopPropagation()}
            >
              <button onClick={() => setSelectedReceipt(null)} className="absolute top-4 right-4 p-2 bg-black/10 hover:bg-black/20 rounded-full z-10"><X size={20} /></button>
              {selectedReceipt.endsWith('.pdf') ? (
                <iframe src={selectedReceipt} className="w-full h-full border-none" />
              ) : (
                <div className="w-full h-full flex items-center justify-center p-8">
                  <img src={selectedReceipt} alt="Receipt" className="max-w-full max-h-full object-contain rounded-xl" referrerPolicy="no-referrer" />
                </div>
              )}
            </motion.div>
          </div>
        )}

        {confirmModal && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[70] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl"
            >
              <div className="p-6 border-b border-black/5 flex justify-between items-center">
                <h3 className="text-lg font-bold">{confirmModal.title}</h3>
                <button onClick={() => setConfirmModal(null)} className="p-2 hover:bg-black/5 rounded-full"><X size={20} /></button>
              </div>
              <div className="p-6">
                <p className="text-black/60 text-sm mb-6">{confirmModal.message}</p>
                <div className="flex gap-3">
                  <Button variant="secondary" className="flex-1" onClick={() => setConfirmModal(null)}>Cancelar</Button>
                  <Button variant="danger" className="flex-1" onClick={confirmModal.onConfirm}>Excluir</Button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Mobile Nav */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-black/5 p-2 flex justify-around md:hidden z-40">
        {[
          { id: 'dashboard', icon: LayoutDashboard },
          { id: 'patients', icon: Users },
          { id: 'vaquinhas', icon: Heart },
          { id: 'financial', icon: Wallet },
          { id: 'reports', icon: BarChart3 },
        ].map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id as any)}
            className={cn(
              "p-3 rounded-xl transition-all",
              activeTab === item.id ? "bg-black text-white" : "text-black/40"
            )}
          >
            <item.icon size={24} />
          </button>
        ))}
      </nav>
    </div>
    </ErrorBoundary>
  );
}
