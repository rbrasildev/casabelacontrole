import Database from 'better-sqlite3';
try {
  const db = new Database('finance.db');
  const result = db.prepare('PRAGMA integrity_check').get();
  console.log('Integrity check result:', result);
  db.close();
} catch (err) {
  console.error('Error checking integrity:', err);
}
