import express from 'express';
import { createServer as createViteServer } from 'vite';
import Database from 'better-sqlite3';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import session from 'express-session';
import bcrypt from 'bcryptjs';

declare module 'express-session' {
  interface SessionData {
    userId: number;
    username: string;
    role: string;
    name: string;
  }
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database('finance.db');

// Initialize Database
try {
  db.exec(`
    CREATE TABLE IF NOT EXISTS fixed_expenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      description TEXT,
      amount REAL NOT NULL,
      due_day INTEGER NOT NULL,
      notes TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS fixed_expense_payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      fixed_expense_id INTEGER NOT NULL,
      month INTEGER NOT NULL,
      year INTEGER NOT NULL,
      status TEXT DEFAULT 'Pending',
      paid_at DATETIME,
      FOREIGN KEY (fixed_expense_id) REFERENCES fixed_expenses(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT NOT NULL,
      description TEXT NOT NULL,
      category TEXT NOT NULL,
      amount REAL NOT NULL,
      type TEXT NOT NULL, -- 'Receita' or 'Despesa'
      payment_method TEXT,
      notes TEXT,
      receipt_path TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS patients (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      full_name TEXT NOT NULL,
      dob TEXT,
      cpf_id TEXT,
      phone TEXT,
      address TEXT,
      city TEXT,
      state TEXT,
      responsible_person TEXT,
      responsible_contact TEXT,
      entry_date TEXT,
      exit_date TEXT,
      medical_observations TEXT,
      status TEXT DEFAULT 'Ativo', -- 'Ativo' or 'Alta'
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS patient_documents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      file_path TEXT NOT NULL,
      uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS vaquinhas (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT,
      goal_amount REAL,
      current_amount REAL DEFAULT 0,
      pix_key TEXT,
      status TEXT DEFAULT 'Aberta', -- 'Aberta' or 'Encerrada'
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS bill_reminders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      month TEXT NOT NULL, -- Format: 'MM/YYYY'
      amount REAL DEFAULT 0,
      due_date TEXT,
      notes TEXT,
      status TEXT DEFAULT 'Pendente', -- 'Pendente' or 'Enviado'
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      name TEXT NOT NULL,
      role TEXT DEFAULT 'User', -- 'Admin' or 'User'
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  try {
    db.exec(`ALTER TABLE patients ADD COLUMN address TEXT;`);
  } catch (e) {
    // Column might already exist
  }
} catch (e) {
  console.error("Database initialization error:", e);
}

const app = express();
app.use(express.json());

app.use(session({
  secret: 'fintrack-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: { 
    secure: false, // Set to true if using HTTPS
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  }
}));

// Auth Middleware
const requireAuth = (req: any, res: any, next: any) => {
  if (req.session.userId) {
    next();
  } else {
    res.status(401).json({ error: 'Unauthorized' });
  }
};

const requireAdmin = (req: any, res: any, next: any) => {
  if (req.session.userId && req.session.role === 'Admin') {
    next();
  } else {
    res.status(403).json({ error: 'Forbidden' });
  }
};

// Auth Routes
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  const user: any = db.prepare('SELECT * FROM users WHERE username = ?').get(username);

  if (user && bcrypt.compareSync(password, user.password)) {
    req.session.userId = user.id;
    req.session.username = user.username;
    req.session.role = user.role;
    req.session.name = user.name;
    res.json({ id: user.id, username: user.username, role: user.role, name: user.name });
  } else {
    res.status(401).json({ error: 'Invalid credentials' });
  }
});

app.post('/api/auth/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) return res.status(500).json({ error: 'Could not log out' });
    res.json({ success: true });
  });
});

app.get('/api/auth/me', (req, res) => {
  if (req.session.userId) {
    res.json({ 
      id: req.session.userId, 
      username: req.session.username, 
      role: req.session.role, 
      name: req.session.name 
    });
  } else {
    res.status(401).json({ error: 'Not logged in' });
  }
});

// User Management Routes
app.get('/api/users', requireAdmin, (req, res) => {
  const users = db.prepare('SELECT id, username, name, role, created_at FROM users').all();
  res.json(users);
});

app.post('/api/users', requireAdmin, (req, res) => {
  const { username, password, name, role } = req.body;
  const hashedPassword = bcrypt.hashSync(password, 10);
  try {
    const info = db.prepare('INSERT INTO users (username, password, name, role) VALUES (?, ?, ?, ?)')
      .run(username, hashedPassword, name, role || 'User');
    res.json({ id: info.lastInsertRowid });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/users/:id', requireAdmin, (req, res) => {
  const { username, name, role, password } = req.body;
  if (password) {
    const hashedPassword = bcrypt.hashSync(password, 10);
    db.prepare('UPDATE users SET username = ?, name = ?, role = ?, password = ? WHERE id = ?')
      .run(username, name, role, hashedPassword, req.params.id);
  } else {
    db.prepare('UPDATE users SET username = ?, name = ?, role = ? WHERE id = ?')
      .run(username, name, role, req.params.id);
  }
  res.json({ success: true });
});

app.delete('/api/users/:id', requireAdmin, (req, res) => {
  // Prevent deleting self
  if (parseInt(req.params.id) === req.session.userId) {
    return res.status(400).json({ error: 'Cannot delete yourself' });
  }
  db.prepare('DELETE FROM users WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// Request logging
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
  next();
});

// File Upload Setup
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ storage });

app.use('/uploads', express.static(uploadDir));

// --- API ROUTES ---

// Fixed Expenses
app.get('/api/fixed-expenses', (req, res) => {
  const month = parseInt(req.query.month as string) || new Date().getMonth() + 1;
  const year = parseInt(req.query.year as string) || new Date().getFullYear();

  const expenses = db.prepare('SELECT * FROM fixed_expenses').all();
  
  const results = expenses.map((exp: any) => {
    const payment = db.prepare('SELECT * FROM fixed_expense_payments WHERE fixed_expense_id = ? AND month = ? AND year = ?')
      .get(exp.id, month, year);
    
    return {
      ...exp,
      status: payment ? (payment.status === 'Paid' ? 'Pago' : 'Pendente') : 'Pendente',
      paid_at: payment ? payment.paid_at : null
    };
  });

  res.json(results);
});

app.post('/api/fixed-expenses', (req, res) => {
  const { name, description, amount, due_day, notes } = req.body;
  const info = db.prepare('INSERT INTO fixed_expenses (name, description, amount, due_day, notes) VALUES (?, ?, ?, ?, ?)')
    .run(name, description, amount, due_day, notes);
  res.json({ id: info.lastInsertRowid });
});

app.put('/api/fixed-expenses/:id', (req, res) => {
  const { name, description, amount, due_day, notes } = req.body;
  db.prepare('UPDATE fixed_expenses SET name = ?, description = ?, amount = ?, due_day = ?, notes = ? WHERE id = ?')
    .run(name, description, amount, due_day, notes, req.params.id);
  res.json({ success: true });
});

app.delete('/api/fixed-expenses/:id', (req, res) => {
  db.prepare('DELETE FROM fixed_expenses WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

app.post('/api/fixed-expenses/:id/pay', (req, res) => {
  const { month, year } = req.body;
  const existing = db.prepare('SELECT id FROM fixed_expense_payments WHERE fixed_expense_id = ? AND month = ? AND year = ?')
    .get(req.params.id, month, year);

  if (existing) {
    db.prepare("UPDATE fixed_expense_payments SET status = 'Paid', paid_at = CURRENT_TIMESTAMP WHERE id = ?")
      .run(existing.id);
  } else {
    db.prepare("INSERT INTO fixed_expense_payments (fixed_expense_id, month, year, status, paid_at) VALUES (?, ?, ?, 'Paid', CURRENT_TIMESTAMP)")
      .run(req.params.id, month, year);
  }
  res.json({ success: true });
});

// Transactions
app.get('/api/transactions', (req, res) => {
  const transactions = db.prepare('SELECT * FROM transactions ORDER BY date DESC').all();
  res.json(transactions);
});

app.post('/api/transactions', upload.single('receipt'), (req: any, res) => {
  const { date, description, category, amount, type, payment_method, notes } = req.body;
  const receipt_path = req.file ? `/uploads/${req.file.filename}` : null;

  const info = db.prepare(`
    INSERT INTO transactions (date, description, category, amount, type, payment_method, notes, receipt_path)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(date, description, category, amount, type, payment_method, notes, receipt_path);

  res.json({ id: info.lastInsertRowid });
});

app.put('/api/transactions/:id', upload.single('receipt'), (req: any, res) => {
  const { date, description, category, amount, type, payment_method, notes } = req.body;
  const transaction = db.prepare('SELECT receipt_path FROM transactions WHERE id = ?').get(req.params.id);
  
  let receipt_path = transaction ? transaction.receipt_path : null;
  if (req.file) {
    // Delete old receipt if exists
    if (receipt_path) {
      const fullPath = path.join(__dirname, receipt_path);
      if (fs.existsSync(fullPath)) fs.unlinkSync(fullPath);
    }
    receipt_path = `/uploads/${req.file.filename}`;
  }

  db.prepare(`
    UPDATE transactions 
    SET date = ?, description = ?, category = ?, amount = ?, type = ?, payment_method = ?, notes = ?, receipt_path = ?
    WHERE id = ?
  `).run(date, description, category, amount, type, payment_method, notes, receipt_path, req.params.id);

  res.json({ success: true });
});

app.delete('/api/transactions/:id', (req, res) => {
  const transaction = db.prepare('SELECT receipt_path FROM transactions WHERE id = ?').get(req.params.id);
  if (transaction && transaction.receipt_path) {
    const fullPath = path.join(__dirname, transaction.receipt_path);
    if (fs.existsSync(fullPath)) fs.unlinkSync(fullPath);
  }
  db.prepare('DELETE FROM transactions WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// Dashboard Stats
app.get('/api/dashboard', (req, res) => {
  const month = parseInt(req.query.month as string) || new Date().getMonth() + 1;
  const year = parseInt(req.query.year as string) || new Date().getFullYear();
  const monthStr = month.toString().padStart(2, '0');
  const datePattern = `${year}-${monthStr}-%`;

  const income = db.prepare("SELECT SUM(amount) as total FROM transactions WHERE type = 'Receita' AND date LIKE ?")
    .get(datePattern).total || 0;
  
  const expenses = db.prepare("SELECT SUM(amount) as total FROM transactions WHERE type = 'Despesa' AND date LIKE ?")
    .get(datePattern).total || 0;

  const fixedExpensesList = db.prepare('SELECT * FROM fixed_expenses').all();
  let fixedTotal = 0;
  let fixedPaid = 0;
  
  fixedExpensesList.forEach((exp: any) => {
    fixedTotal += exp.amount;
    const payment = db.prepare('SELECT status FROM fixed_expense_payments WHERE fixed_expense_id = ? AND month = ? AND year = ?')
      .get(exp.id, month, year);
    if (payment && payment.status === 'Paid') {
      fixedPaid += exp.amount;
    }
  });

  res.json({
    monthlyIncome: income,
    monthlyExpenses: expenses,
    fixedExpensesTotal: fixedTotal,
    fixedExpensesPaid: fixedPaid,
    remainingBalance: income - expenses - (fixedTotal - fixedPaid) // Balance after all obligations
  });
});

// Reports
app.get('/api/reports/category', (req, res) => {
  const month = parseInt(req.query.month as string) || new Date().getMonth() + 1;
  const year = parseInt(req.query.year as string) || new Date().getFullYear();
  const monthStr = month.toString().padStart(2, '0');
  const datePattern = `${year}-${monthStr}-%`;

  const report = db.prepare(`
    SELECT category, SUM(amount) as total 
    FROM transactions 
    WHERE type = 'Despesa' AND date LIKE ? 
    GROUP BY category
  `).all(datePattern);

  res.json(report);
});

app.get('/api/reports/fixed-expenses-history', (req, res) => {
  const history = [];
  const now = new Date();
  const monthNames = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
  
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const month = d.getMonth() + 1;
    const year = d.getFullYear();
    
    const fixedExpensesList = db.prepare('SELECT * FROM fixed_expenses').all();
    let fixedPaid = 0;
    
    fixedExpensesList.forEach((exp: any) => {
      const payment = db.prepare('SELECT status FROM fixed_expense_payments WHERE fixed_expense_id = ? AND month = ? AND year = ?')
        .get(exp.id, month, year);
      if (payment && payment.status === 'Paid') {
        fixedPaid += exp.amount;
      }
    });
    
    history.push({
      name: monthNames[d.getMonth()],
      total: fixedPaid,
      month: month,
      year: year
    });
  }
  
  res.json(history);
});

// Patients
app.get('/api/patients', (req, res) => {
  const patients = db.prepare('SELECT * FROM patients ORDER BY full_name ASC').all();
  const results = patients.map((p: any) => {
    const documents = db.prepare('SELECT * FROM patient_documents WHERE patient_id = ?').all(p.id);
    return { ...p, documents };
  });
  res.json(results);
});

app.get('/api/patients/:id', (req, res) => {
  const patient = db.prepare('SELECT * FROM patients WHERE id = ?').get(req.params.id);
  if (!patient) return res.status(404).json({ error: 'Patient not found' });
  const documents = db.prepare('SELECT * FROM patient_documents WHERE patient_id = ?').all(req.params.id);
  res.json({ ...patient, documents });
});

app.post('/api/patients', (req, res) => {
  const { full_name, dob, cpf_id, phone, address, city, state, responsible_person, responsible_contact, entry_date, exit_date, medical_observations, status } = req.body;
  const info = db.prepare(`
    INSERT INTO patients (full_name, dob, cpf_id, phone, address, city, state, responsible_person, responsible_contact, entry_date, exit_date, medical_observations, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(full_name, dob, cpf_id, phone, address, city, state, responsible_person, responsible_contact, entry_date, exit_date, medical_observations, status || 'Ativo');
  res.json({ id: info.lastInsertRowid });
});

app.put('/api/patients/:id', (req, res) => {
  const { full_name, dob, cpf_id, phone, address, city, state, responsible_person, responsible_contact, entry_date, exit_date, medical_observations, status } = req.body;
  db.prepare(`
    UPDATE patients SET 
      full_name = ?, dob = ?, cpf_id = ?, phone = ?, address = ?, city = ?, state = ?, 
      responsible_person = ?, responsible_contact = ?, entry_date = ?, 
      exit_date = ?, medical_observations = ?, status = ?
    WHERE id = ?
  `).run(full_name, dob, cpf_id, phone, address, city, state, responsible_person, responsible_contact, entry_date, exit_date, medical_observations, status, req.params.id);
  res.json({ success: true });
});

app.delete('/api/patients/:id', (req, res) => {
  db.prepare('DELETE FROM patients WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

app.post('/api/patients/:id/documents', upload.single('document'), (req: any, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const file_path = `/uploads/${req.file.filename}`;
  const name = req.body.name || req.file.originalname;
  db.prepare('INSERT INTO patient_documents (patient_id, name, file_path) VALUES (?, ?, ?)')
    .run(req.params.id, name, file_path);
  res.json({ success: true, file_path });
});

app.delete('/api/documents/:id', (req, res) => {
  const doc = db.prepare('SELECT file_path FROM patient_documents WHERE id = ?').get(req.params.id);
  if (doc && doc.file_path) {
    const fullPath = path.join(__dirname, doc.file_path);
    if (fs.existsSync(fullPath)) fs.unlinkSync(fullPath);
  }
  db.prepare('DELETE FROM patient_documents WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// Vaquinhas
app.get('/api/vaquinhas', (req, res) => {
  const vaquinhas = db.prepare('SELECT * FROM vaquinhas ORDER BY created_at DESC').all();
  res.json(vaquinhas);
});

app.post('/api/vaquinhas', (req, res) => {
  const { title, description, goal_amount, pix_key } = req.body;
  const info = db.prepare('INSERT INTO vaquinhas (title, description, goal_amount, pix_key) VALUES (?, ?, ?, ?)')
    .run(title, description, goal_amount, pix_key);
  res.json({ id: info.lastInsertRowid });
});

app.put('/api/vaquinhas/:id', (req, res) => {
  const { title, description, goal_amount, current_amount, pix_key, status } = req.body;
  db.prepare('UPDATE vaquinhas SET title = ?, description = ?, goal_amount = ?, current_amount = ?, pix_key = ?, status = ? WHERE id = ?')
    .run(title, description, goal_amount, current_amount, pix_key, status, req.params.id);
  res.json({ success: true });
});

app.delete('/api/vaquinhas/:id', (req, res) => {
  db.prepare('DELETE FROM vaquinhas WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// Bill Reminders API
app.get('/api/bill-reminders', (req, res) => {
  const { month, year } = req.query;
  let query = 'SELECT * FROM bill_reminders';
  const params: any[] = [];

  if (month && year) {
    query += ' WHERE month = ?';
    params.push(`${month.toString().padStart(2, '0')}/${year}`);
  }

  const reminders = db.prepare(`${query} ORDER BY due_date ASC`).all(...params);
  res.json(reminders);
});

app.post('/api/bill-reminders', (req, res) => {
  const { name, month, amount, due_date, notes } = req.body;
  const info = db.prepare('INSERT INTO bill_reminders (name, month, amount, due_date, notes) VALUES (?, ?, ?, ?, ?)')
    .run(name, month, amount, due_date, notes);
  res.json({ id: info.lastInsertRowid });
});

app.put('/api/bill-reminders/:id', (req, res) => {
  const { name, month, amount, due_date, notes, status } = req.body;
  db.prepare('UPDATE bill_reminders SET name = ?, month = ?, amount = ?, due_date = ?, notes = ?, status = ? WHERE id = ?')
    .run(name, month, amount, due_date, notes, status, req.params.id);
  res.json({ success: true });
});

app.patch('/api/bill-reminders/:id/status', (req, res) => {
  const { status } = req.body;
  db.prepare('UPDATE bill_reminders SET status = ? WHERE id = ?')
    .run(status, req.params.id);
  res.json({ success: true });
});

app.delete('/api/bill-reminders/:id', (req, res) => {
  db.prepare('DELETE FROM bill_reminders WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// --- API 404 HANDLER ---
app.use('/api', (req, res) => {
  res.status(404).json({ error: 'API route not found' });
});

// Global Error Handler
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error('SERVER ERROR:', err);
  
  if (err.message && err.message.includes('database disk image is malformed')) {
    return res.status(500).json({ 
      error: 'Database Error', 
      message: 'O banco de dados está corrompido. Por favor, contate o suporte.',
      code: 'DB_MALFORMED'
    });
  }

  res.status(500).json({ 
    error: 'Internal Server Error', 
    message: err.message,
    stack: process.env.NODE_ENV === 'production' ? undefined : err.stack 
  });
});

// --- VITE MIDDLEWARE ---
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  const PORT = 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
